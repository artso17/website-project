const bungkus=document.querySelector('.bungkus');
const body=document.body

window.addEventListener('load',function(){
    bungkus.className+=' hidden';
})

const text=document.querySelector('.myportfolio-text p').innerHTML
console.log(text)
